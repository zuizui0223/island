README for data archive pertaining to Whitehead et al (2018) "Plant Mating Systems Often Vary Widely Among Populations" Frontiers in Ecology and Evolution
-----
Column Name (Notes)

Notes for "PopTmData_Whitehead_etal.csv"

species_name (name of species in study)
study_number (index number given to each study providing data)
genus (genus of species in study)
species (specific epithet of species in study)
total_pops (total population Tm estimates from that species and study)
pop_code (population number assigned to each Tm estimate in study)
biotic_poll (0 = abiotic pollination, 1 = biotic pollination, 2 = both biotic and abiotic pollination)
primary_poll (broad classes of pollination mechanism: insect, bird, mammal, cleistogamy, wind)
poll_detail (more specific notes on type of pollen vectors)
poll_obs (1 = pollinator observed in the study presenting Tm values, 2 = pollination referenced to another study, 0 = no pollination data/evidence provided)
year_published (year study was published)
first_author (first author surname for each study)
multiyear (0 = populations sampled for a single season, 1 = some/all populations sampled over multiple seasons)
Tm (outcrossing estimate)
standard_error (standard error associated with each Tm estimate)
notes (other remarks about the population or study)


Notes for "SpeciesTmData_Whitehead_etal.csv"

species (species in study)
genus (genus name)
family (family according to The Plant List)
mean_tm (species average Tm across all reported population Tm estimates)
var_tm (species variance in Tm among all reported population Tm estimates)
pops (number of populations reporting Tm)
search_term (name used to search NCBI database)
entrez_binomial (species name as reported on NCBI Genbank database)
taxon_ID (taxon ID assigned by NCBI Genbank)
matK_species (is the longest matK accession available for the species)
matk_final (is the accession that was used for phylogenetic inference. Where there is a value for matk_species, this will also be the value in matk_final. But where there was no accession for a given species, we can sometimes use a matK accession from a congener, following the approach that is outlined in https://www.ncbi.nlm.nih.gov/pubmed/21835254)


Notes for "DataReferences_Whitehead_etal.csv"

first_author (surname of first author for the study)
year_published (year the paper was published)
full_reference (full reference for the study)